"use strict";
(() => {
var exports = {};
exports.id = 515;
exports.ids = [515];
exports.modules = {

/***/ 6207:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _slug_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/blogPage/BlogSidebar/BlogSidebar.js


const BlogSidebar = ({ post: post1 , posts , categories  })=>{
    var ref;
    const { avatar_urls , name , description  } = post1[0]._embedded.author[0];
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("aside", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "share-post",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        children: "Share On:"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `https://www.facebook.com/sharer.php?u=https://creativepeoplesdesign.com/post/${post1[0].slug}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fab fa-facebook"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `https://twitter.com/share?url=https://creativepeoplesdesign.com/post/${post1[0].slug}&text=${post1[0].title.rendered}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fab fa-twitter"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `https://pinterest.com/pin/create/bookmarklet/?media=${(ref = post1[0]._embedded['wp:featuredmedia']) === null || ref === void 0 ? void 0 : ref['0'].source_url}&url=https://creativepeoplesdesign.com/post/${post1[0].slug}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fab fa-pinterest"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `https://www.linkedin.com/shareArticle?url=https://creativepeoplesdesign.com/post/${post1[0].slug}&title=${post1[0].title.rendered}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fab fa-linkedin-in"
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "profile",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: "img-fluid",
                        src: avatar_urls['96'],
                        alt: name
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                        children: [
                            "About ",
                            name
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: description
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "recent-post",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        children: "Recent Posts"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "recent-posts-list",
                        children: posts && posts.slice(0, 3).map((post)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "recent-post-item",
                                children: [
                                    post.x_featured_media_original && /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: post.x_featured_media_original,
                                        alt: post.title.rendered
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "rp-content",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                    href: `/post/${post.slug}`,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        dangerouslySetInnerHTML: {
                                                            __html: post.title.rendered
                                                        }
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                dangerouslySetInnerHTML: {
                                                    __html: post.excerpt.rendered.slice(0, 50)
                                                }
                                            })
                                        ]
                                    })
                                ]
                            }, post.id)
                        )
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const BlogSidebar_BlogSidebar = (BlogSidebar);

// EXTERNAL MODULE: ./components/shared/Layout/Layout.js + 12 modules
var Layout = __webpack_require__(5757);
;// CONCATENATED MODULE: external "axios"
const external_axios_namespaceObject = require("axios");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_namespaceObject);
// EXTERNAL MODULE: external "moment"
var external_moment_ = __webpack_require__(2245);
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_);
// EXTERNAL MODULE: ./components/blogPage/BlogCard/BlogCard.js
var BlogCard = __webpack_require__(5841);
;// CONCATENATED MODULE: ./pages/post/[slug]/index.js










const BlogDetails = ({ post: post1 , posts , categories  })=>{
    var ref4, ref1, ref2;
    const { 0: comment , 1: setComment  } = (0,external_react_.useState)({});
    const { 0: comments , 1: setComments  } = (0,external_react_.useState)([]);
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(false);
    const router = (0,router_.useRouter)();
    const slug = router.query;
    const { id , title , content , excerpt , link  } = post1[0];
    const newContent = content.rendered.replaceAll(link + '#', '#');
    // refs
    const nameRef = (0,external_react_.useRef)();
    const emailRef = (0,external_react_.useRef)();
    const commentRef = (0,external_react_.useRef)();
    (0,external_react_.useEffect)(()=>{
        setLoading(true);
        const fetchAllComments = async ()=>{
            const { data  } = await external_axios_default()(`https://creativepeoples.xyz/projects/cp-next-admin/wp-json/wp/v2/comments?post=${id}`);
            setComments(data);
            setLoading(false);
        };
        fetchAllComments();
    }, [
        id,
        comment
    ]);
    const handleCommentForm = async (e)=>{
        setLoading(true);
        e.preventDefault();
        const commentObj = {
            post: id,
            author_name: nameRef.current.value,
            author_email: emailRef.current.value,
            content: commentRef.current.value
        };
        const { data  } = await external_axios_default().post('https://creativepeoples.xyz/projects/cp-next-admin/wp-json/wp/v2/comments', commentObj);
        setComment(data);
        setLoading(false);
        setComments([
            ...comments,
            comment
        ]);
        e.target.reset();
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: title.rendered
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: excerpt.rendered
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "blog-details-page",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container custom_container",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-9",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "blog-details-post",
                                        children: [
                                            ((ref4 = post1[0]) === null || ref4 === void 0 ? void 0 : ref4.x_featured_media_original) && /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                className: "w-100",
                                                src: (ref1 = post1[0]) === null || ref1 === void 0 ? void 0 : ref1.x_featured_media_original,
                                                alt: title === null || title === void 0 ? void 0 : title.rendered
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "blog-meta",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "far fa-clock me-2"
                                                            }),
                                                            external_moment_default()(post1[0].date).format('MMM Do YY')
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "far fa-user me-2"
                                                            }),
                                                            " by",
                                                            ' ',
                                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                                href: `/author/${post1[0]._embedded.author[0].id}`,
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                    className: "text-capitalize",
                                                                    children: post1[0]._embedded.author[0].name
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "far fa-comments me-2"
                                                            }),
                                                            ' ',
                                                            ((ref2 = post1._embedded) === null || ref2 === void 0 ? void 0 : ref2.replies) ? post1._embedded.replies[0].length : 0,
                                                            ' ',
                                                            "Comments"
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                dangerouslySetInnerHTML: {
                                                    __html: title === null || title === void 0 ? void 0 : title.rendered
                                                }
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "content",
                                                dangerouslySetInnerHTML: {
                                                    __html: newContent
                                                }
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "row",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "col-lg-8",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "blog-form",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                                children: "Leave us a message"
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                                                onSubmit: handleCommentForm,
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "form-group",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                            ref: nameRef,
                                                                            required: true,
                                                                            type: "text",
                                                                            className: "form-control",
                                                                            placeholder: "Name"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "form-group",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                            ref: emailRef,
                                                                            required: true,
                                                                            type: "email",
                                                                            className: "form-control",
                                                                            placeholder: "email"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "form-group",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                                                            ref: commentRef,
                                                                            className: "form-control",
                                                                            placeholder: "Message"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                        type: "submit",
                                                                        value: loading ? 'Posting' : 'Publish'
                                                                    })
                                                                ]
                                                            }),
                                                            comments.length > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: "comments-list",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                                        children: "Comments"
                                                                    }),
                                                                    comments.map((c)=>{
                                                                        var ref, ref3;
                                                                        /*#__PURE__*/ return (0,jsx_runtime_.jsxs)("div", {
                                                                            className: "comment-item",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                    className: "comment-avatar",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                                        src: c === null || c === void 0 ? void 0 : (ref = c.author_avatar_urls) === null || ref === void 0 ? void 0 : ref[96],
                                                                                        alt: ""
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                    className: "comment-right",
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                                                            children: c.author_name
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                            className: "comment-body",
                                                                                            dangerouslySetInnerHTML: {
                                                                                                __html: c === null || c === void 0 ? void 0 : (ref3 = c.content) === null || ref3 === void 0 ? void 0 : ref3.rendered
                                                                                            }
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                            children: external_moment_default()(c.date).format('MMM Do YY')
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        }, c.id);
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-3",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(BlogSidebar_BlogSidebar, {
                                        post: post1,
                                        posts: posts,
                                        categories: categories
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row related_posts",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-12 text-center",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "cre_cta_content",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "title",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Related Posts"
                                            })
                                        })
                                    })
                                }),
                                posts.slice(0, 3).map((post)=>/*#__PURE__*/ jsx_runtime_.jsx(BlogCard/* default */.Z, {
                                        post: post
                                    }, post.id)
                                )
                            ]
                        })
                    ]
                })
            })
        ]
    }));
};
const getServerSideProps = async (context)=>{
    const postsRes = await await fetch('https://creativepeoples.xyz/projects/cp-next-admin/wp-json/wp/v2/posts?_embed');
    const res = await fetch(`https://creativepeoples.xyz/projects/cp-next-admin/wp-json/wp/v2/posts?slug=${context.params.slug}&_embed`);
    const catRes = await fetch('https://creativepeoples.xyz/projects/cp-next-admin/wp-json/wp/v2/categories');
    const posts = await postsRes.json();
    const post = await res.json();
    const categories = await catRes.json();
    return {
        props: {
            post,
            posts,
            categories
        }
    };
};
/* harmony default export */ const _slug_ = (BlogDetails);


/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 358:
/***/ ((module) => {

module.exports = require("react-bootstrap");

/***/ }),

/***/ 3286:
/***/ ((module) => {

module.exports = require("react-mailchimp-subscribe");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,664,757,841], () => (__webpack_exec__(6207)));
module.exports = __webpack_exports__;

})();