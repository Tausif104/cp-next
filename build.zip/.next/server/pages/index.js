"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 7757:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/shared/Layout/Layout.js + 12 modules
var Layout = __webpack_require__(5757);
// EXTERNAL MODULE: external "react-countup"
var external_react_countup_ = __webpack_require__(609);
var external_react_countup_default = /*#__PURE__*/__webpack_require__.n(external_react_countup_);
;// CONCATENATED MODULE: ./components/homePage/about/images/arrow-shape.png
/* harmony default export */ const arrow_shape = ({"src":"/_next/static/media/arrow-shape.c908e0c8.png","height":137,"width":193,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAASFBMVEXyZSLuZyHxZSHyZCLyZCHxZCHxZSHxZSHxZCHxZSHxZSHxZSHxZSHxZSHxZSHxZCHxZCHxZCHxZCHxZCHxZSHxZCHxZCHxZSHMqzYFAAAAGHRSTlMAAAAAAAABAgIDBAYRFBcbHCEjKzc/QVUs3bLTAAAAM0lEQVR42gWAhxGAIBAEz9XHgApP7L9TRrADSPnf6kdAt/fhBoI4Eu8jTszLbDLCQfRrASa8AZnw+ODgAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/homePage/about/images/s_defferent_icon1.png
/* harmony default export */ const s_defferent_icon1 = ({"src":"/_next/static/media/s_defferent_icon1.9ee143d4.png","height":51,"width":51,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAsElEQVR42l2OrQpCQRCFRzH5CEZBUBAuaFcErRZ3zDZ/gsquf8V0BYWdokVuErEabL6eX7jJhY9z5szszopw1FtFg1Wdjxd8imbUR3iICzEhWDhvc/SqPi7xO7xHDwzYiSLADExDHCsX8CMGVoJ5YzqEbfRFvYY7DFlxFsIpa2oEZfweWlDnLwM0E6aaND/wJezL/6GRQhd6sIFGnpd0GwvCrSevTBR48kYjyQeKIiI/xY1fPMViaXcAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./components/homePage/about/images/s_defferent_icon2.png
/* harmony default export */ const s_defferent_icon2 = ({"src":"/_next/static/media/s_defferent_icon2.25cd7ea0.png","height":50,"width":50,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAq0lEQVR42j2PMQoCMRBFg63YeQBP4A3EKwgm2tgIFlYWmW5RcFcE10TbIK6FhTaCjb1n80WyO/CY+fN/IKNiaeu6sII7vGGuKCOuVQem2voPnJgreBnrOqouxEKLvxF4QCCQgWkCiIkW10vzmdCAPmrMtBwm3Ycleh+9uMgRT9gqamyPbXZfdEkvYyAz4g/pgpmW/zUV/1rTNwpzhwjG+oJXV3oglGNejPjiB3sTXiXjUkjuAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/homePage/about/images/s_defferent_icon3.png
/* harmony default export */ const s_defferent_icon3 = ({"src":"/_next/static/media/s_defferent_icon3.ff4e8010.png","height":51,"width":51,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAnElEQVR42m2NIQ4CQQxFCwGBwIGAJRmBx0EIDr8JCZkxKAQBg2BnLgBmBe2dOAGCG/HIDm6bvPT/tvkVH7UIyYY+2ljaisUZXjD4+RAtoAuofNKjIHYh6YmULfoKb1LvcIFnk5JshqlZOvqmSdY9rP4HNaYvbcXPG0uDEazhwG+XU3pC7ANRwZLjkv6BST7okqALRJkHc3Awzb7zBZfxSgIEiGLHAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/homePage/about/images/s_defferent_icon4.png
/* harmony default export */ const s_defferent_icon4 = ({"src":"/_next/static/media/s_defferent_icon4.4037ef18.png","height":51,"width":51,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAq0lEQVR42jWOPQvCMBCGQ90cBEd3URBEUDqLkygWtU0KolhxEEEQ2ugfcL30P/tE08DDm7t770P5Z6zr6Mr1dCVXuMDU2Lr1KxK0KabaugzdEe/REyTpSyKlrcQkCxITdIXO0Ri8acB4udM9Dqs+xI8w+WxoVLgKGEECTyhh4VdB7p0zOAbjEhJTOX/oAfoqf9fRv1s096Sw5r81mFXzslIwyZDiDd3Q0G1qX/G6WQITSmkeAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/homePage/about/images/s_defferent_icon5.png
/* harmony default export */ const s_defferent_icon5 = ({"src":"/_next/static/media/s_defferent_icon5.9630847d.png","height":51,"width":51,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAApUlEQVR42k2PvQ5BQRCFJ66oRKEieg3R66hEFJpdiV5DQmS3ktvQUMw8gjfyUr7JveJOcrLnZzZ7Vnxi0nZIegvJgJ7AEz6W3yDOYPnXOkTfY7aehGyjkPXqQczagc9Z+IAj2Ub8JljxzBa8QRmTHVjY4UeBJLBA9DkHLEyEqf0pxGaQlzQGz4vum8aaQmXdoxspWHFrEWrhgnIX+IPQvxiq71vxBXtZTkSlHmkfAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/homePage/about/about.js








const About = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "cre_about_section section_padding position-relative",
        "data-bg-color": "#F4F4F4",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container custom_container",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row align-items-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-10 wow fadeIn",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "cre_section_title",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                        className: "title",
                                        children: [
                                            "A Full-Stack ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Creative Agency"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "description",
                                        children: "CreativePeoples is a prominent Graphic, Web Design and Digital Marketing Agency that builds unique brands and digital experiences for clients. As your business partner, CreativePeoples designs user-oriented products and services that increase conversions, drive sales and connect with customers."
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row why_different gy-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-4 col-lg-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "cre_section_title",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "title",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Why Are We Different From Others?"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: arrow_shape.src,
                                            alt: "arrow_shape",
                                            className: "img-fluid arrow_shape"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-4 col-lg-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "single_different_item",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "s_different_icon",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: s_defferent_icon1.src,
                                                alt: "single_why_diffrent_icon",
                                                className: "img-fluid"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "Digital Services That Clients Love"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "We apply behavioral research and science to the consumer experience and design appealing digital services to help secure your business's growth."
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-4 col-lg-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "single_different_item",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "s_different_icon",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: s_defferent_icon2.src,
                                                alt: "single_why_diffrent_icon",
                                                className: "img-fluid"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "Websites That Empower Your Brand"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Our delivered high-quality websites represent the power of your brand and boost your business's visibility, sales, and value."
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-4 col-lg-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "single_different_item",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "s_different_icon",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: s_defferent_icon3.src,
                                                alt: "single_why_diffrent_icon",
                                                className: "img-fluid"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "Latest Strategies That Ensure ROI"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Your partnership with us is always our top priority, and we imply diversified and proven designing, developing, and marketing strategists to ensure ROI."
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-4 col-lg-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "single_different_item",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "s_different_icon",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: s_defferent_icon4.src,
                                                alt: "single_why_diffrent_icon",
                                                className: "img-fluid"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "Insightful and User-Centric Practices"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Creativepeoples leverages the power of research and data to extract insights that result in positive business growth and enhance the shared human experience."
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-4 col-lg-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "single_different_item",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "s_different_icon",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: s_defferent_icon5.src,
                                                alt: "single_why_diffrent_icon",
                                                className: "img-fluid"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "Future-Oriented Mindset"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Last not least, we rethink your digital products, help grow your brands, and investigate the golden future of mobility for millions of visitors."
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row justify-content-between",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-3 col-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "cre_counter_text",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                            className: "counter_number",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "counter",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_countup_default()), {
                                                        start: 0,
                                                        end: 1100,
                                                        duration: 5
                                                    })
                                                }),
                                                "+"
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "description",
                                            children: "Completed projects"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-3 col-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "cre_counter_text",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                            className: "counter_number",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "counter",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_countup_default()), {
                                                        start: 0,
                                                        end: 800,
                                                        duration: 5
                                                    })
                                                }),
                                                "+"
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "description",
                                            children: "Worldwide Customer"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-3 col-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "cre_counter_text",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                            className: "counter_number",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "counter",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_countup_default()), {
                                                        start: 0,
                                                        end: 600,
                                                        duration: 5
                                                    })
                                                }),
                                                "+"
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "description",
                                            children: "Five Star Review"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-3 col-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "cre_counter_text",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                            className: "counter_number",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "counter",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_countup_default()), {
                                                        start: 0,
                                                        end: 15,
                                                        duration: 5
                                                    })
                                                }),
                                                "+"
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "description",
                                            children: "Team Member"
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "cre_parallax_section rotated-section-title wow fadeIn",
                children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    className: "parallax_text",
                    children: "About"
                })
            })
        ]
    }));
};
/* harmony default export */ const about = (About);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/homePage/banner/banner.jpg
/* harmony default export */ const banner = ({"src":"/_next/static/media/banner.dca117cd.jpg","height":962,"width":2784,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAMACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAgQg//8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k="});
;// CONCATENATED MODULE: ./components/homePage/banner/banner.js



const Banner = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "cre_banner",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "banner-bg",
                style: {
                    backgroundImage: `url(${banner.src})`,
                    backgroundColor: '#111',
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                    backgroundAttachment: 'fixed'
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container custom_container",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row align-items-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-11",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "cre_banner_wrapper wow fadeInUp",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                    className: "title text-white",
                                    children: [
                                        "A Full-Stack Creative",
                                        ' ',
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "Design, Development & Strategic Digital Marketing"
                                        }),
                                        ' ',
                                        "Agency"
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "animate_border_wrapper",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "/projects",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: "cr_btn_style animate_border",
                                            children: "See Our Works"
                                        })
                                    })
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "slider",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "slide-track",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "slide"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "slide"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "slide"
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const banner_banner = (Banner);

;// CONCATENATED MODULE: ./components/homePage/services/serviceMobile.js

const ServiceMobile = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "service-mobile d-xl-none d-lg-none d-md-none d-sm-block d-block",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "accordion",
            id: "accordionExample",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "accordion-item",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "accordion-header",
                            id: "serviceOne",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "accordion-button",
                                type: "button",
                                "data-bs-toggle": "collapse",
                                "data-bs-target": "#serviceColOne",
                                "aria-expanded": "true",
                                "aria-controls": "serviceColOne",
                                children: "Design"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            id: "serviceColOne",
                            className: "accordion-collapse collapse show",
                            "aria-labelledby": "serviceOne",
                            "data-bs-parent": "#accordionExample",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "accordion-body",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "Analysis & Strategy"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "Branding Design"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "Marketing Material Design"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "Mobile App Design"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "UI Design"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "UX Design"
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "accordion-item",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "accordion-header",
                            id: "serviceTwo",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "accordion-button collapsed",
                                type: "button",
                                "data-bs-toggle": "collapse",
                                "data-bs-target": "#serviceColTwo",
                                "aria-expanded": "false",
                                "aria-controls": "serviceColTwo",
                                children: "Development"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            id: "serviceColTwo",
                            className: "accordion-collapse collapse",
                            "aria-labelledby": "serviceTwo",
                            "data-bs-parent": "#accordionExample",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "accordion-body",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "UX Design"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "Branding Design"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "Marketing Material Design"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "Analysis & Strategy"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "UI Design"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "Mobile App Design"
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "accordion-item",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "accordion-header",
                            id: "serviceThree",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "accordion-button collapsed",
                                type: "button",
                                "data-bs-toggle": "collapse",
                                "data-bs-target": "#serviceColThree",
                                "aria-expanded": "false",
                                "aria-controls": "serviceColThree",
                                children: "Marketing"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            id: "serviceColThree",
                            className: "accordion-collapse collapse",
                            "aria-labelledby": "serviceThree",
                            "data-bs-parent": "#accordionExample",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "accordion-body",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "Marketing Material Design"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "Branding Design"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "UI Design"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "Analysis & Strategy"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "UX Design"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "Mobile App Design"
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const serviceMobile = (ServiceMobile);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/homePage/services/images/service-bg-1.jpg
/* harmony default export */ const service_bg_1 = ({"src":"/_next/static/media/service-bg-1.f4a539e5.jpg","height":746,"width":1128,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABQEBAQAAAAAAAAAAAAAAAAAAAgP/2gAMAwEAAhADEAAAAI4q/wD/xAAbEAADAAIDAAAAAAAAAAAAAAABAgMABAYSUv/aAAgBAQABPwDkuosb6pFrOKq7hXbssx5XP//EABYRAAMAAAAAAAAAAAAAAAAAAAABMf/aAAgBAgEBPwBQ/8QAFxEAAwEAAAAAAAAAAAAAAAAAAAECIf/aAAgBAwEBPwCEqWn/2Q=="});
;// CONCATENATED MODULE: ./components/homePage/services/images/service-bg-2.jpg
/* harmony default export */ const service_bg_2 = ({"src":"/_next/static/media/service-bg-2.fe5507f9.jpg","height":746,"width":1128,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAABAX/2gAMAwEAAhADEAAAAJ+ET//EABsQAAEEAwAAAAAAAAAAAAAAAAIAAQMRBBIx/9oACAEBAAE/AIcUDKPcYys2YrDrWv/EABYRAQEBAAAAAAAAAAAAAAAAAAEAAv/aAAgBAgEBPwDQX//EABgRAAIDAAAAAAAAAAAAAAAAAAACAyJx/9oACAEDAQE/AIXa2n//2Q=="});
;// CONCATENATED MODULE: ./components/homePage/services/images/service-bg-3.jpg
/* harmony default export */ const service_bg_3 = ({"src":"/_next/static/media/service-bg-3.e9a0cc23.jpg","height":746,"width":1128,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAABAX/2gAMAwEAAhADEAAAAJqFTf/EAB0QAAIBBAMAAAAAAAAAAAAAAAECAwAEBRESMVL/2gAIAQEAAT8AxLqlw24w3KJ1B8kjuv/EABYRAAMAAAAAAAAAAAAAAAAAAAADMv/aAAgBAgEBPwBcn//EABcRAAMBAAAAAAAAAAAAAAAAAAADMoH/2gAIAQMBAT8AdeH/2Q=="});
;// CONCATENATED MODULE: ./components/homePage/services/services.js






const Services = ()=>{
    (0,external_react_.useEffect)(()=>{
        // service tabs
        const serviceNavs = document.querySelectorAll('.service-tabs span');
        const designNav = document.getElementById('design-item');
        const devNav = document.getElementById('dev-item');
        const marketingnNav = document.getElementById('marketing-item');
        const serviceBody = document.getElementsByClassName('service-body');
        const designBody = document.getElementById('service-design');
        const devBody = document.getElementById('service-dev');
        const marketingBody = document.getElementById('service-marketing');
        const serviceSection = document.getElementById('service-section');
        const hideServices = ()=>{
            for (const service of serviceBody){
                service.style.display = 'none';
            }
        };
        hideServices();
        const removeActiveNav = ()=>{
            for (const serviceNav of serviceNavs){
                if (serviceNav.classList) {
                    serviceNav.classList.remove('active');
                }
            }
        };
        designBody.style.display = 'block';
        serviceSection.style.backgroundImage = `url(${service_bg_1.src})`;
        designNav.addEventListener('mouseover', (e)=>{
            removeActiveNav();
            hideServices();
            e.target.classList.add('active');
            designBody.style.display = 'block';
            serviceSection.style.backgroundImage = `url(${service_bg_1.src})`;
        });
        devNav.addEventListener('mouseover', (e)=>{
            removeActiveNav();
            hideServices();
            e.target.classList.add('active');
            devBody.style.display = 'block';
            serviceSection.style.backgroundImage = `url(${service_bg_2.src})`;
        });
        marketingnNav.addEventListener('mouseover', (e)=>{
            removeActiveNav();
            hideServices();
            e.target.classList.add('active');
            marketingBody.style.display = 'block';
            serviceSection.style.backgroundImage = `url(${service_bg_3.src})`;
        });
    }, []);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                id: "service-section",
                className: "services_section sec_padding design-bg d-xl-block d-lg-block d-md-block d-sm-none d-none",
                style: {
                    backgroundSize: 'cover',
                    backgroundPosition: 'center'
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container custom_container",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row align-items-center",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "col-lg-12",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "cre_parallax_section wow fadeInUp",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "parallax_text",
                                        children: "services"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "services_list_wrapper position-relative",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "row justify-content-between align-items-center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col-lg-6",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "service-tabs",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            id: "design-item",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "active",
                                                                children: "Design"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            id: "dev-item",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                children: "Development"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            id: "marketing-item",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                children: "Marketing"
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-lg-6",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "service-body",
                                                        id: "service-design",
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "UI/UX Design"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "Landing Page Design"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "Web Design"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "Mobile App Design"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "Logo Design"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "Brand Design"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "service-body",
                                                        id: "service-dev",
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "Wordpress Development"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "API Integration"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "Responsive Web Design"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "eCommerce Development"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "Web Application"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "Content Management Systems"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "service-body ",
                                                        id: "service-marketing",
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "Search Engine Optimization (SEO)"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "Search Engine Marketing (SEM)"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "Pay Per Click Advertising"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "Social Media Management"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "Onsite & Offsite Marketing"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: "Content Generation and Optimization"
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(serviceMobile, {})
        ]
    }));
};
/* harmony default export */ const services = (Services);

// EXTERNAL MODULE: ./components/homePage/solutions/solutions.js + 6 modules
var solutions = __webpack_require__(6505);
;// CONCATENATED MODULE: ./components/shared/cta/cta.js


const Cta = ({ id  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "cre_section section_padding",
        id: id,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container custom_container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row justify-content-between align-items-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-6 wow fadeInLeft",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "cre_cta_content",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                    className: "title",
                                    children: [
                                        "Let’s ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "Talk"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "description",
                                    children: "We don't have a magic wand to solve the above-mentioned problems. But we can work with you on designing a great SaaS product that provides the value your custom ers are looking for."
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-5 wow fadeInRight",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "animate_border_wrapper mt-4 mt-lg-0 float-end cta-btn-wrapper",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/contact",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: "cr_btn_style animate_border",
                                    children: "Get Custom Quote"
                                })
                            })
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const cta = (Cta);

;// CONCATENATED MODULE: ./components/homePage/portfolio/images/portfolio.png
/* harmony default export */ const portfolio = ({"src":"/_next/static/media/portfolio.ec09e5b7.png","height":904,"width":1920,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAj0lEQVR4nAGEAHv/Ae3v9fH59vmZDRMPpNjT0OazytYAgTweGpjyHV3q+/5mAXmSxeUsG/rwJCETEc3OyuX18/L/MhYVHNDU1fCx2eMPAWdzgfHo6er0GxsTBBAKCQL38/QAzNzk/SsY+/0TDfYMAS04Qvr7/wD8/Pz7AhIRE/8DAwMADgsLAfDy7/729/YETZFGt2MhO9MAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./components/homePage/portfolio/images/portfolio-mobile-img.png
/* harmony default export */ const portfolio_mobile_img = ({"src":"/_next/static/media/portfolio-mobile-img.9bd1d7e4.png","height":450,"width":375,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAA5ElEQVR42jXBUSsEURgG4Pf7ztFmTEmbZrYNUbSKJEqLlL30P/wqt8qlf0EubMqsrckNS4mdGbs7zO4453yu9nlIpAsMqwCw74w955nZXGzBN3f30M8xty+uLs3Zaas8XJ8/ciBkP4zuQwQNpXebe5vo50WUZPRtPdHJ50g2trZFHRy31jzfDzUK10t/6f31pX/7lgzjkdO6Ez2G9XoYlJaDySCD51Wq1x/6L1VqTnee4spXOugZgYFYAikOJ/ADYqGFRrOd5WMLRYyxsY3VWrBUW1x2xlha2TkpFRMJpogtwCLAP1+DZOHyDOE+AAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/homePage/portfolio/portfolio.js




const Portfolios = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "cre_portfolio_section portfolio_bg portfolio_overlay section_padding",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container custom_container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row justify-content-center position-relative z_index_10",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-xxl-7 col-lg-9",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "section_title text-center position-relative",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "cre_parallax_section wow fadeInUp",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "parallax_text",
                                        children: "our works"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "title text-white wow fadeInUp",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "Portfolio"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: "description text-white wow fadeInUp mb-3",
                                    children: [
                                        "CreativePeoples is specialized in designing your Web, App UI/ UX, Graphics, or Logo and Branding.",
                                        ' ',
                                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                            children: "Also, we offer full-stack services on Web Development, Digital Marketing (SEO, PPC, Creative Content), etc., that are efficient, attractive, and aim at your client's audience."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "description text-white wow fadeInUp",
                                    children: "We've had the pleasure of working with several customers over the years and successfully represented a diverse range of business models through our products and services. To discover more about our work, please view our portfolio."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "animate_border_wrapper mt-4 wow fadeInUp",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "/contact",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: "cr_btn_style animate_border",
                                            children: "Get Custom Quote"
                                        })
                                    })
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row justify-content-center wow fadeIn",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-12",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "cre_portfolio_wrapper",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    className: "projects-img-mobile d-xl-none d-lg-none d-md-none d-sm-block d-block",
                                    src: portfolio_mobile_img.src,
                                    alt: "portfolio.png"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    className: "d-xl-block d-lg-block d-md-block d-sm-none d-none",
                                    src: portfolio.src,
                                    alt: "portfolio.png"
                                })
                            ]
                        })
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const portfolio_portfolio = (Portfolios);

// EXTERNAL MODULE: external "moment"
var external_moment_ = __webpack_require__(2245);
// EXTERNAL MODULE: ./components/blogPage/BlogCard/BlogCard.js
var BlogCard = __webpack_require__(5841);
;// CONCATENATED MODULE: ./components/homePage/latestBlog/LatestBlog.js




const LatestBlog = ({ posts  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
            className: "cre_blog_section section_padding position-relative",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container custom_container",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row justify-content-between mb_80 blog_title_wraper",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-4",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "section_title mb-0",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                            className: "title wow fadeInLeft",
                                            children: [
                                                "Our Latest ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Blog Posts"
                                                }),
                                                ' '
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-5 wow fadeInRight",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "description",
                                        children: "We post blogs to help developing new creativity and educate businesses in designing niche. Checkout our recent blog posts..."
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "row g-4",
                            children: (posts === null || posts === void 0 ? void 0 : posts.length) > 0 && posts.slice(0, 3).map((post)=>/*#__PURE__*/ jsx_runtime_.jsx(BlogCard/* default */.Z, {
                                    post: post,
                                    column: 3
                                }, post.id)
                            )
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "cre_parallax_section wow fadeIn",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "parallax_text",
                        children: "blogs"
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const latestBlog_LatestBlog = (LatestBlog);

;// CONCATENATED MODULE: ./components/homePage/Testmonial/images/testimonial-bg.jpg
/* harmony default export */ const testimonial_bg = ({"src":"/_next/static/media/testimonial-bg.8855fb4d.jpg","height":930,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAAAwEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAkHl//8QAHBAAAQMFAAAAAAAAAAAAAAAAAgADBAYSITSi/9oACAEBAAE/AKTcIYEkcbN3C//EABkRAQACAwAAAAAAAAAAAAAAAAIAAREhQf/aAAgBAgEBPwAgWDdg53yf/8QAGBEAAgMAAAAAAAAAAAAAAAAAARIAAhH/2gAIAQMBAT8Aa2kMZ//Z"});
;// CONCATENATED MODULE: ./components/homePage/Testmonial/Testimonial.js



const Testimonial = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "cre_testimonial_section section_padding testimonial_bg",
        style: {
            backgroundImage: `url(${testimonial_bg.src})`
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container custom_container",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row position-relative",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-lg-7",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "cre_testimonial_wrapper",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: "title fw-bold text-white mb-4 pb-2 wow fadeInUp",
                                children: "We are eager to help you on your project."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "description font_300 text-white wow fadeInUp",
                                children: "CreativePeoples provide services worldwide. We offer a full design suit for your business and help you reach your goals."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "client_info wow fadeInUp",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "client_name text-white font_700",
                                        children: "Simon Sontag"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                        className: "client_position font_400 text-white",
                                        children: "Project Manager at Kiwi Solutions"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/reviews",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: "cu_btn btn_1 text-uppercase wow fadeInUp",
                                    children: "See All Reviews"
                                })
                            })
                        ]
                    })
                })
            })
        })
    }));
};
/* harmony default export */ const Testmonial_Testimonial = (Testimonial);

// EXTERNAL MODULE: ./components/shared/CtaTwo/CtaTwo.js
var CtaTwo = __webpack_require__(3276);
;// CONCATENATED MODULE: ./components/homePage/Clients/images/clients-bg.png
/* harmony default export */ const clients_bg = ({"src":"/_next/static/media/clients-bg.60fab89a.png","height":826,"width":1920,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADBAMAAABc5lN7AAAAJFBMVEUiM0IgMD8fMD8kLT8eLz4fLjweLj0dLj0eLTwgLDsfLDweLDv4Spe2AAAAF0lEQVR42mMoL1HdyVBenrGLobyEsRkAKPwFSaTByT8AAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./components/homePage/Clients/Clients.js



const Clients = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "clients_section",
        style: {
            backgroundImage: `url(${clients_bg.src})`
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container custom_container",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row align-items-center clients_section_title_wrap",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-8",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "section_title",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "title",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "Testimonial"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "You Can See Our Clients Feedback"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-4",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "clients_button text-end",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "animate_border_wrapper wow fadeInUp",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "/reviews",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: "cr_btn_style animate_border",
                                            children: "See All Reviews"
                                        })
                                    })
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row client_boxes gy-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "single_client_box",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "s_clients_author_meta_wrap",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "s_clients_author_info",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    children: "saviodesigns"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Marketplace Client"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "clients_messege",
                                        children: "Loved the talked/artistic skill/willingness to take feedback and make adjustments. Definitely a great experience and I hope to work with him again!!!"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "s_clients_quote_wrap",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "clients_bullets",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fas fa-star"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fas fa-star"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fas fa-star"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fas fa-star"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fas fa-star"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fas fa-quote-right"
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "single_client_box",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "s_clients_author_meta_wrap",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "s_clients_author_info",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    children: "josephbenstowe"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Marketplace Client"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "clients_messege",
                                        children: "Seller was great I can tell the design he chose was 100% authentic and custom and it look incredibly high quality"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "s_clients_quote_wrap",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "clients_bullets",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fas fa-star"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fas fa-star"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fas fa-star"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fas fa-star"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fas fa-star"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fas fa-quote-right"
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const Clients_Clients = (Clients);

;// CONCATENATED MODULE: ./pages/index.js













function Home({ posts  }) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "CreativePeoples - A Prominent Web Design & Developing Company"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Are you searching for reliable, trustworthy, and superior web design and developing services? Then don't look any further, and CreativePeoples is here!"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(banner_banner, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(about, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(services, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(solutions/* default */.Z, {
                        title: 'Solutions <span>We Provide</span>'
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(cta, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(portfolio_portfolio, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(latestBlog_LatestBlog, {
                        posts: posts
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Clients_Clients, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Testmonial_Testimonial, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(CtaTwo/* default */.Z, {
                        title: "We’re ready to grow with you. <span>Talk to an expert today.</span>",
                        desc: "At CreativePeoples, we are committed to authenticity, consistency, integrity, and excellent consumer experience-we are not satisfied with our outcomes or creations until you are. Contact us today to learn more about how we can assist you in growing your business."
                    })
                ]
            })
        ]
    }));
};
async function getServerSideProps() {
    const res = await fetch('https://creativepeoples.xyz/projects/cp-next-admin/wp-json/wp/v2/posts?_embed');
    const posts = await res.json();
    return {
        props: {
            posts
        }
    };
}


/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 358:
/***/ ((module) => {

module.exports = require("react-bootstrap");

/***/ }),

/***/ 609:
/***/ ((module) => {

module.exports = require("react-countup");

/***/ }),

/***/ 3286:
/***/ ((module) => {

module.exports = require("react-mailchimp-subscribe");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,664,757,276,841,505], () => (__webpack_exec__(7757)));
module.exports = __webpack_exports__;

})();