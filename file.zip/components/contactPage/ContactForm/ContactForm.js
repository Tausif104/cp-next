import MailChimpForm from '../MailChimpForm'

const ContactForm = () => {
	return (
		<div className='contact_form_wrapper bg-white wow fadeIn'>
			<MailChimpForm />
		</div>
	)
}

export default ContactForm
