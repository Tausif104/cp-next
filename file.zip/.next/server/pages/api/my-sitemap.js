"use strict";
(() => {
var exports = {};
exports.id = 112;
exports.ids = [112];
exports.modules = {

/***/ 8297:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ my_sitemap)
});

;// CONCATENATED MODULE: external "sitemap"
const external_sitemap_namespaceObject = require("sitemap");
;// CONCATENATED MODULE: external "axios"
const external_axios_namespaceObject = require("axios");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/my-sitemap.js


/* harmony default export */ const my_sitemap = (async (req, res)=>{
    try {
        const smStream = new external_sitemap_namespaceObject.SitemapStream({
            hostname: `https://${req.headers.host}`,
            cacheTime: 600000
        });
        // List of posts
        const { data  } = await external_axios_default().get('https://creativepeoplesdesign.com/admin/wp-json/wp/v2/posts?_embed');
        // Create each URL row
        data.forEach((post)=>{
            smStream.write({
                url: `/${post.slug}`,
                changefreq: 'daily',
                priority: 0.9
            });
        });
        // End sitemap stream
        smStream.end();
        // XML sitemap string
        const sitemapOutput = (await (0,external_sitemap_namespaceObject.streamToPromise)(smStream)).toString();
        // Change headers
        res.writeHead(200, {
            'Content-Type': 'application/xml'
        });
        // Display output to user
        res.end(sitemapOutput);
    } catch (e) {
        console.log(e);
        res.send(JSON.stringify(e));
    }
});


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8297));
module.exports = __webpack_exports__;

})();