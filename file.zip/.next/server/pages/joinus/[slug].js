"use strict";
(() => {
var exports = {};
exports.id = 103;
exports.ids = [103];
exports.modules = {

/***/ 5991:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _slug_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
// EXTERNAL MODULE: ./components/shared/Layout/Layout.js + 12 modules
var Layout = __webpack_require__(5757);
// EXTERNAL MODULE: ./components/shared/PageBanner/PageBanner.js
var PageBanner = __webpack_require__(1895);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
;// CONCATENATED MODULE: ./components/jobs/ApplyForm.js




const ApplyForm = ()=>{
    const { 0: firstName , 1: setFirstName  } = (0,external_react_.useState)("");
    const { 0: lastName , 1: setLastName  } = (0,external_react_.useState)("");
    const { 0: email , 1: setEmail  } = (0,external_react_.useState)("");
    const { 0: portfolio , 1: setPortfolio  } = (0,external_react_.useState)("");
    const { 0: phone , 1: setPhone  } = (0,external_react_.useState)("");
    const { 0: resume , 1: setResume  } = (0,external_react_.useState)("");
    const { 0: about , 1: setAbout  } = (0,external_react_.useState)("");
    const { 0: alert , 1: setAlert  } = (0,external_react_.useState)("");
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)("");
    const handleSubmit = async (e)=>{
        setLoading(true);
        e.preventDefault();
        let formData = new FormData();
        formData.append("firstName", firstName);
        formData.append("lastName", lastName);
        formData.append("email", email);
        formData.append("portfolio", portfolio);
        formData.append("phone", phone);
        formData.append("resume", resume);
        formData.append("about", about);
        e.target.reset();
        const { data  } = await external_axios_default().post("https://creativepeoplesdesign.com/admin/wp-json/contact-form-7/v1/contact-forms/199/feedback", formData);
        setLoading(false);
        if (data.status === "mail_sent") {
            setAlert("We have got your information. Will contact you later");
        } else {
            setAlert("Mail not sent");
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "apply-form",
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Container, {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Row, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                        md: 12,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "section-title",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "Apply for"
                                    }),
                                    " this Job"
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                        md: 12,
                        children: alert ? /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Alert, {
                            className: "text-center",
                            variant: "success",
                            children: alert
                        }) : /*#__PURE__*/ jsx_runtime_.jsx("form", {
                            onSubmit: handleSubmit,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Row, {
                                className: "g-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                        md: 4,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "form-group",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                    htmlFor: "",
                                                    children: "First Name"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                    onChange: (e)=>setFirstName(e.target.value),
                                                    type: "text",
                                                    placeholder: "First Name",
                                                    className: "form-control"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                        md: 4,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "form-group",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                    htmlFor: "",
                                                    children: "Last Name"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                    onChange: (e)=>setLastName(e.target.value),
                                                    type: "text",
                                                    placeholder: "Last Name",
                                                    className: "form-control"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                        md: 4,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "form-group",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                    htmlFor: "",
                                                    children: "Email"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                    onChange: (e)=>setEmail(e.target.value),
                                                    type: "email",
                                                    placeholder: "Email Address",
                                                    className: "form-control"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                        md: 4,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "form-group",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                    htmlFor: "",
                                                    children: "Portfolio"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                    onChange: (e)=>setPortfolio(e.target.value),
                                                    type: "url",
                                                    placeholder: "Portfolio Link",
                                                    className: "form-control"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                        md: 4,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "form-group",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                    htmlFor: "",
                                                    children: "Phone"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                    onChange: (e)=>setPhone(e.target.value),
                                                    type: "tel",
                                                    placeholder: "Phone Number",
                                                    className: "form-control"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                        md: 4,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "form-group",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                    htmlFor: "",
                                                    children: "Resume"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                    onChange: (e)=>setResume(e.target.files[0]),
                                                    type: "file",
                                                    placeholder: "Resume",
                                                    className: "form-control"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                        md: 12,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "form-group",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                    htmlFor: "",
                                                    children: "Write about yourself"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                                    onChange: (e)=>setAbout(e.target.value),
                                                    className: "form-control",
                                                    placeholder: "Tell us about yourself in few lines"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                        md: 12,
                                        className: "text-center",
                                        children: loading ? /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Spinner, {
                                            animation: "border",
                                            role: "status",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "visually-hidden",
                                                children: "Loading..."
                                            })
                                        }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "animate_border_wrapper mt-4",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                type: "submit",
                                                className: "cr_btn_style animate_border",
                                                children: "Apply Now"
                                            })
                                        })
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const jobs_ApplyForm = (ApplyForm);

;// CONCATENATED MODULE: ./pages/joinus/[slug]/index.js






const Jobs = ({ jobs  })=>{
    const job = jobs[0];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(PageBanner/* default */.Z, {
                title: "Job Vacancy"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "jobs-description-section",
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Container, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Row, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "jobs-desc",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        children: job.title.rendered
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "jobs-meta",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fas fa-map-marker-alt"
                                                    }),
                                                    " ",
                                                    job.x_metadata.location
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fas fa-money-bill"
                                                    }),
                                                    " ",
                                                    job.x_metadata.salary
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fas fa-calendar-check"
                                                    }),
                                                    " ",
                                                    job.x_metadata.type
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "job-details",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            dangerouslySetInnerHTML: {
                                                __html: job.content.rendered
                                            }
                                        })
                                    })
                                ]
                            })
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(jobs_ApplyForm, {})
        ]
    });
};
async function getServerSideProps(context) {
    const { data: jobs  } = await external_axios_default().get(`https://creativepeoplesdesign.com/admin/wp-json/wp/v2/job?slug=${context.params.slug}&_embed`);
    return {
        props: {
            jobs
        }
    };
}
/* harmony default export */ const _slug_ = (Jobs);


/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 358:
/***/ ((module) => {

module.exports = require("react-bootstrap");

/***/ }),

/***/ 3286:
/***/ ((module) => {

module.exports = require("react-mailchimp-subscribe");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664,757,895], () => (__webpack_exec__(5991)));
module.exports = __webpack_exports__;

})();