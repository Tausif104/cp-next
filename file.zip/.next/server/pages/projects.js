"use strict";
(() => {
var exports = {};
exports.id = 327;
exports.ids = [327];
exports.modules = {

/***/ 7427:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_projects),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./components/projectPage/LinkCard/LinkCard.js

const LinkCard = ({ link  })=>{
    const { acf , title , x_featured_media_original  } = link;
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "col-xl-3 col-lg-4 col-md-6",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "linkcard",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    className: "img-fluid",
                    src: x_featured_media_original,
                    alt: title.rendered
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "link-card-content",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        target: "_blank",
                        rel: "noreferrer",
                        href: acf.link_url,
                        children: title.rendered
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const LinkCard_LinkCard = (LinkCard);

;// CONCATENATED MODULE: ./components/projectPage/LiveLinks/LivelinkList.js


const LivelinkList = ({ links  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "live-site-links gray-bg section_padding",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container custom_container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row mb-4",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-12",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "section-title text-center",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                className: "title",
                                children: [
                                    "Samples Of Our ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "Previous Works"
                                    })
                                ]
                            })
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row g-xl-4 g-lg-4 g-md-4 g-4",
                    children: links.map((link)=>/*#__PURE__*/ jsx_runtime_.jsx(LinkCard_LinkCard, {
                            link: link
                        }, link.id)
                    )
                })
            ]
        })
    }));
};
/* harmony default export */ const LiveLinks_LivelinkList = (LivelinkList);

// EXTERNAL MODULE: external "moment"
var external_moment_ = __webpack_require__(2245);
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/projectPage/ProjectCard/ProjectCard.js



const ProjectCard = ({ project  })=>{
    const { id , title , published_at , images  } = project;
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "col-xl-4 col-lg-4 col-md-6 wow fadeInUp",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "project-item",
            style: {
                backgroundImage: `url(${images.hidpi ? images.hidpi : images.normal})`
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "project-item-meta d-flex justify-content-between align-items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "meta-left",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                children: title
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "far fa-clock me-"
                                    }),
                                    ' ',
                                    external_moment_default()(published_at).format('MMM Do YY')
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "meta-right",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: `/project/${id}`,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fas fa-arrow-right"
                                })
                            })
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const ProjectCard_ProjectCard = (ProjectCard);

;// CONCATENATED MODULE: ./components/projectPage/ProjectList/ProjectList.js


const ProjectList = ({ projects  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "project-list-section",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container custom_container",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row g-xl-4 g-lg-4 g-md-4 g-4 justify-content-center",
                    children: projects.map((project)=>/*#__PURE__*/ jsx_runtime_.jsx(ProjectCard_ProjectCard, {
                            project: project
                        }, project.id)
                    )
                })
            })
        })
    }));
};
/* harmony default export */ const ProjectList_ProjectList = (ProjectList);

// EXTERNAL MODULE: ./components/shared/Layout/Layout.js + 12 modules
var Layout = __webpack_require__(5757);
// EXTERNAL MODULE: ./components/shared/PageBanner/PageBanner.js
var PageBanner = __webpack_require__(1895);
;// CONCATENATED MODULE: ./pages/projects.js






const projects = ({ projects: projects1 , links  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Fully Customer Satisfied Projects"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "We have delivered 1100+ customer-satisfied projects with smiles, happiness, joys, and charm. Click here and spread your joy with everyone!"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(PageBanner/* default */.Z, {
                title: "Projects"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ProjectList_ProjectList, {
                projects: projects1
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(LiveLinks_LivelinkList, {
                links: links
            })
        ]
    }));
};
async function getStaticProps() {
    const res = await fetch('https://api.dribbble.com/v2/user/shots?access_token=1d41a60e6a59faef44cabd36abcf7003292ec9a0a49fc2db833e2c537bcb86b5');
    const linkRes = await fetch('https://creativepeoplesdesign.com/admin/wp-json/wp/v2/link?per_page=100&&_embed');
    const projects2 = await res.json();
    const links = await linkRes.json();
    return {
        props: {
            projects: projects2,
            links
        },
        revalidate: 10
    };
}
/* harmony default export */ const pages_projects = (projects);


/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 358:
/***/ ((module) => {

module.exports = require("react-bootstrap");

/***/ }),

/***/ 3286:
/***/ ((module) => {

module.exports = require("react-mailchimp-subscribe");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,664,757,895], () => (__webpack_exec__(7427)));
module.exports = __webpack_exports__;

})();