"use strict";
(() => {
var exports = {};
exports.id = 675;
exports.ids = [675];
exports.modules = {

/***/ 7870:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ SitemapIndex),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_sitemap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4279);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_sitemap__WEBPACK_IMPORTED_MODULE_1__]);
next_sitemap__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const getServerSideProps = async (ctx)=>{
    const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default()("https://creativepeoplesdesign.com/admin/wp-json/wp/v2/posts?per_page=100&&_embed");
    const fields = data.map((item)=>({
            loc: `https://creativepeoplesdesign.com/${item.slug}`,
            lastmod: item.updatedAt,
            priority: 0.7,
            changefreq: "daily"
        }));
    return (0,next_sitemap__WEBPACK_IMPORTED_MODULE_1__.getServerSideSitemap)(ctx, fields);
};
function SitemapIndex() {};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 4279:
/***/ ((module) => {

module.exports = import("next-sitemap");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7870));
module.exports = __webpack_exports__;

})();