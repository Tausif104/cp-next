"use strict";
exports.id = 505;
exports.ids = [505];
exports.modules = {

/***/ 6505:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ solutions)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/homePage/solutions/icons/solution_icon1.png
/* harmony default export */ const solution_icon1 = ({"src":"/_next/static/media/solution_icon1.e5e1c0c0.png","height":50,"width":50,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAoklEQVR42i3IMS4EAQAF0PfHoBGRkEhWFHsIjSuIlk5FodzEPXTbuICKhtYVtK4gUdhKothvCsVrXlY384VaJI7boGusw1g+B7LAees9IQySsYkkh6N2hgfMq8KH9g0H5XtIsjE5mexFlEe8hh2cjm2f8YsNDIjkUrvEy3+YTfYnm/hSZ+IJHZPcVXexxhWCbbIFAVhdz28lS+09LpIcaX/+AGtcNUdihIWMAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/homePage/solutions/icons/solution_icon2.png
/* harmony default export */ const solution_icon2 = ({"src":"/_next/static/media/solution_icon2.f0b2459f.png","height":50,"width":50,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAl0lEQVR42l3NMS4DYAAG0Pfxk0oTicEgsZCYDA5jcQCTk4iVxe5MYmWRNCmKLk3qs4p3gZfF5XH9k/QTD5qrEb3DwCZWmKileKT3Q1zgA984wAwrdS62R2svXCOVKf0KR+VJcztCcIoZPQlzkXBWbBRYiP3ES5n8adYjrMuzOiSvdNmai4X0Z2CL3NC36I7YbfOedlq2fwFwKz61O8XiFwAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./components/homePage/solutions/icons/solution_icon3.png
/* harmony default export */ const solution_icon3 = ({"src":"/_next/static/media/solution_icon3.9b66f9e4.png","height":50,"width":50,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAoUlEQVR42iWOMQ7CMAxFfZX0MNwBsTprJWCBBSQEQwciEAOwVOrCJbgPE0sywYDC+zA82Xn+dW05hq54U6nv7OFVYlN/eKi8O2N4yQgCO0SiVuhxCl4NOUfMqCfCB+oIxrCCqbHKaY6g0AJaWILCbqy5sWHgEWEDW3B+MWimG84E7rCGBHv1cpop0Evy1QRaob7gNDNdzh0fxAOerAb6v0tflOmFq5d05wAAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./components/homePage/solutions/icons/solution_icon4.png
/* harmony default export */ const solution_icon4 = ({"src":"/_next/static/media/solution_icon4.84e26ee2.png","height":60,"width":60,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAsklEQVR42jXOPQ4BQRiA4ck4gIpGQmZColIoyWrZgmSmWCQU6ChUGolonMElHEAnohBn0GhcYOYCu+9mdyd58v3mywhnlBQ8b1QLK2y80fW8VxLpYynACV10cEWYDa2uUPzZHmBBPqZ3Jo9RFjRGJE/ixRk9xMdZ1aB+YZIuzFiY4s6gR/1FiDUi4a1uM9wzvHmrtjR31A/ikWvN4pN9vHFAhB+CYiizqGvkcyxRpcV1JRPsAmLHsrqj9wAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./components/homePage/solutions/icons/solution_icon5.png
/* harmony default export */ const solution_icon5 = ({"src":"/_next/static/media/solution_icon5.cb6f2ebe.png","height":50,"width":50,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAoUlEQVR42g3JTSoEAAAG0PeN8be1UOwQuYADuIBTmIO4gaNYO4aQkmymiBrNFKNp9Jm3fZmNDq4xL+vqF1uJdVxhkunlYaUvmKsjcp/0DCd4HkrfcaPW8EQfcYwhDCJ/aiHZDjvYaN1iCpmNDrvymrhrPZAduocJTgerXCYO1BsWdB8/+MbuQDKoEKvwgWniSyzJeJhWE20uEsq47Tk+pZv/HkZGuCIkl3QAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./components/homePage/solutions/icons/solution_icon6.png
/* harmony default export */ const solution_icon6 = ({"src":"/_next/static/media/solution_icon6.730524de.png","height":50,"width":50,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAoElEQVR42k3PoQ7CMBDG8WYZD3L3bK1AI7AIFDiSIRA4ECTAsiBA4kCieAF4gFZgEPDvdmJNfmnX+3bpuRRk4FjJ6yUF/WXR69mxOFOzFb1McDfTfmHEH1f22pywBruOaS3b3LaP4gtfAsc2EIN8uLjhgSffNW97E9jlwJLLBTzmmGGIikDlYtDS3nLAyuy7KaQkIIUFNnRrGLfJZxuz+AMl33EuRUKy6gAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./components/homePage/solutions/solutions.js








const Solutions = (props)=>{
    const { title , extraClass  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: `cre_solutions_section padding_top ${extraClass}`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container custom_container",
            children: [
                title && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-12 wow fadeIn text-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "cre_section_title",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "title",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    dangerouslySetInnerHTML: {
                                        __html: title
                                    }
                                })
                            })
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row gy-4 wow fadeIn",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "single_solution_item",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "s_solution_icon",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: solution_icon1.src,
                                            alt: "solution_icon",
                                            className: "img-fluid"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "s_solution_content",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                children: "Responsive Website Design"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "CreativePeoples specializes in building responsive websites that are visually appealing and rank highly in search results and help you reach your business goals: increased leads, sales, and traffic. We also ensure that the user will always get the best experience by customizing menus and controls to match the device's screen size and height."
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/services/responsive-web",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    className: "read_more",
                                                    children: "Read More"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "single_solution_item",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "s_solution_icon",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: solution_icon2.src,
                                            alt: "solution_icon",
                                            className: "img-fluid"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "s_solution_content",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                children: "UI/UX Design"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "We provide a valuable and robust user experience that progresses your business with a significant competitive advantage in gaining and sustaining customers. Also, we offer out-of-the-box UI/UX design services by following the latest design trends and carefully considering the client's requirements."
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/services/ui-ux-design",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    className: "read_more",
                                                    children: "Read More"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "single_solution_item",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "s_solution_icon",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: solution_icon3.src,
                                            alt: "solution_icon",
                                            className: "img-fluid"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "s_solution_content",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                children: "Landing Page Design"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                                        children: "Whether you want to create brand awareness, get leads, or get more traffic, you'll need an impactful landing page agency on your side."
                                                    }),
                                                    " ",
                                                    "Our most reliable customized and data-driven landing pages enable you to attract more visitors, gain reliability, generate more leads, and boost your brand's reputation."
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/services/landing-page",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    className: "read_more",
                                                    children: "Read More"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "single_solution_item",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "s_solution_icon",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: solution_icon4.src,
                                            alt: "solution_icon",
                                            className: "img-fluid"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "s_solution_content",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                children: "WordPress Development"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Moreover, we develop a comprehensive suite of WordPress development directly for you. Our professional WordPress services will make sure that you have an error-free interface, effective navigation, and user-friendliness of your WordPress site."
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/services/wordpress",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    className: "read_more",
                                                    children: "Read More"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "single_solution_item",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "s_solution_icon",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: solution_icon5.src,
                                            alt: "solution_icon",
                                            className: "img-fluid"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "s_solution_content",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                children: "Logos and Branding"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Our team of experts delivers a well-defined brand strategy that enables you to express your message, quality, and advantages effectively, efficiently, and aesthetically, bringing more attention and creating remarkable interactions. As part of our branding services at CreativePeoples, we believe in designing and re-designing thought-provoking branding services that can add an appealing touch to your overall brand existence. Moreover, our creative and professional team will design innovative and attractive logos for your business that becomes your brand’s identity."
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/services/branding",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    className: "read_more",
                                                    children: "Read More"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "single_solution_item",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "s_solution_icon",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: solution_icon6.src,
                                            alt: "solution_icon",
                                            className: "img-fluid"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "s_solution_content",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                children: "Print Design"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "CreativePeoples designs world-class marketing materials with pixel-perfect strategies for your digital products. We also believe great product results from an impeccable design and we do it perfectly to spread your products, services, promotions, offers, messages worldwide."
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/services/print-designs",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    className: "read_more",
                                                    children: "Read More"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const solutions = (Solutions);


/***/ })

};
;