"use strict";
exports.id = 757;
exports.ids = [757];
exports.modules = {

/***/ 5757:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout_Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/shared/header/logo.png
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.cb68866c.png","height":49,"width":313,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAAK0lEQVR4nGP89++fCwMDAycjIyPr7/dvv36f087CeKn3/38uDX6Gfz+/AgDzIg/GIFgyKQAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./components/shared/header/icons/solution_icon1.png
/* harmony default export */ const solution_icon1 = ({"src":"/_next/static/media/solution_icon1.e5e1c0c0.png","height":50,"width":50,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAoklEQVR42i3IMS4EAQAF0PfHoBGRkEhWFHsIjSuIlk5FodzEPXTbuICKhtYVtK4gUdhKothvCsVrXlY384VaJI7boGusw1g+B7LAees9IQySsYkkh6N2hgfMq8KH9g0H5XtIsjE5mexFlEe8hh2cjm2f8YsNDIjkUrvEy3+YTfYnm/hSZ+IJHZPcVXexxhWCbbIFAVhdz28lS+09LpIcaX/+AGtcNUdihIWMAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/shared/header/icons/solution_icon2.png
/* harmony default export */ const solution_icon2 = ({"src":"/_next/static/media/solution_icon2.f0b2459f.png","height":50,"width":50,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAl0lEQVR42l3NMS4DYAAG0Pfxk0oTicEgsZCYDA5jcQCTk4iVxe5MYmWRNCmKLk3qs4p3gZfF5XH9k/QTD5qrEb3DwCZWmKileKT3Q1zgA984wAwrdS62R2svXCOVKf0KR+VJcztCcIoZPQlzkXBWbBRYiP3ES5n8adYjrMuzOiSvdNmai4X0Z2CL3NC36I7YbfOedlq2fwFwKz61O8XiFwAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./components/shared/header/icons/solution_icon3.png
/* harmony default export */ const solution_icon3 = ({"src":"/_next/static/media/solution_icon3.9b66f9e4.png","height":50,"width":50,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAoUlEQVR42iWOMQ7CMAxFfZX0MNwBsTprJWCBBSQEQwciEAOwVOrCJbgPE0sywYDC+zA82Xn+dW05hq54U6nv7OFVYlN/eKi8O2N4yQgCO0SiVuhxCl4NOUfMqCfCB+oIxrCCqbHKaY6g0AJaWILCbqy5sWHgEWEDW3B+MWimG84E7rCGBHv1cpop0Evy1QRaob7gNDNdzh0fxAOerAb6v0tflOmFq5d05wAAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./components/shared/header/icons/solution_icon4.png
/* harmony default export */ const solution_icon4 = ({"src":"/_next/static/media/solution_icon4.84e26ee2.png","height":60,"width":60,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAsklEQVR42jXOPQ4BQRiA4ck4gIpGQmZColIoyWrZgmSmWCQU6ChUGolonMElHEAnohBn0GhcYOYCu+9mdyd58v3mywhnlBQ8b1QLK2y80fW8VxLpYynACV10cEWYDa2uUPzZHmBBPqZ3Jo9RFjRGJE/ixRk9xMdZ1aB+YZIuzFiY4s6gR/1FiDUi4a1uM9wzvHmrtjR31A/ikWvN4pN9vHFAhB+CYiizqGvkcyxRpcV1JRPsAmLHsrqj9wAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./components/shared/header/icons/solution_icon5.png
/* harmony default export */ const solution_icon5 = ({"src":"/_next/static/media/solution_icon5.cb6f2ebe.png","height":50,"width":50,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAoUlEQVR42g3JTSoEAAAG0PeN8be1UOwQuYADuIBTmIO4gaNYO4aQkmymiBrNFKNp9Jm3fZmNDq4xL+vqF1uJdVxhkunlYaUvmKsjcp/0DCd4HkrfcaPW8EQfcYwhDCJ/aiHZDjvYaN1iCpmNDrvymrhrPZAduocJTgerXCYO1BsWdB8/+MbuQDKoEKvwgWniSyzJeJhWE20uEsq47Tk+pZv/HkZGuCIkl3QAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./components/shared/header/icons/solution_icon6.png
/* harmony default export */ const solution_icon6 = ({"src":"/_next/static/media/solution_icon6.730524de.png","height":50,"width":50,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAoElEQVR42k3PoQ7CMBDG8WYZD3L3bK1AI7AIFDiSIRA4ECTAsiBA4kCieAF4gFZgEPDvdmJNfmnX+3bpuRRk4FjJ6yUF/WXR69mxOFOzFb1McDfTfmHEH1f22pywBruOaS3b3LaP4gtfAsc2EIN8uLjhgSffNW97E9jlwJLLBTzmmGGIikDlYtDS3nLAyuy7KaQkIIUFNnRrGLfJZxuz+AMl33EuRUKy6gAAAABJRU5ErkJggg=="});
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./components/shared/header/header.js











const Header = ()=>{
    const router = (0,router_.useRouter)();
    (0,external_react_.useEffect)(()=>{
        // sticky header
        const headerNav = document.getElementById("headerTop");
        window.addEventListener("scroll", ()=>{
            if (window.scrollY >= 400) {
                headerNav.classList.add("header-fixed");
            } else {
                headerNav.classList.remove("header-fixed");
            }
        });
        // mobile menu
        const menuTrigger = document.getElementById("mobile-menu-trigger");
        const mobileMenu = document.getElementById("mobile-menu");
        const closeTrigger = document.getElementById("close-menu");
        const navItems = document.querySelectorAll(".mobile-menu-items li a");
        const mobileDropdowns = document.querySelector(".mobile-dropdown ul");
        const dropdownNav = document.getElementsByClassName("mobile-dropdown");
        menuTrigger.addEventListener("click", ()=>{
            mobileMenu.classList.add("active");
        });
        closeTrigger.addEventListener("click", ()=>{
            mobileMenu.classList.remove("active");
        });
        for (const navItem of navItems){
            navItem.addEventListener("click", ()=>{
                mobileMenu.classList.remove("active");
            });
        }
        for (const list of dropdownNav){
            list.addEventListener("click", (e)=>{
                mobileDropdowns.classList.toggle("d-none");
            });
        }
        // mobile menu
        const mobileMenuTrigger = document.getElementById("handle-mobile-menu");
        const megaMenu = document.getElementById("mega-menu");
        mobileMenuTrigger.addEventListener("click", (e)=>{
            if (megaMenu.classList.contains("d-block")) {
                megaMenu.classList.remove("d-block");
            } else {
                megaMenu.classList.add("d-block");
            }
        });
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                id: "scrollToTop"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
                className: "site_header ",
                id: "headerTop",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mobile-menu-wrapper",
                        id: "mobile-menu",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                id: "close-menu",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fas fa-times"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mobile-menu-items",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/about",
                                                children: "About"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/services",
                                                    children: "Services"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    id: "handle-mobile-menu",
                                                    className: "mobile_dropdown_trigger",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fas fa-angle-down"
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                    id: "mega-menu",
                                                    className: "mega_menu_wrap mega_menu_mobile",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "/services/responsive-web",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                                className: "mega_link_item",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "mega_link_icon",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                            className: "img-fluid",
                                                                            src: solution_icon1.src,
                                                                            alt: "mega_menu_link_icon"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "mega_link_description",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                                children: "Responsive Website Design"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                children: "Do you know, about 75% of your clients browse your website from mobile?"
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "/services/ui-ux-design",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                                className: "mega_link_item",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "mega_link_icon",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                            className: "img-fluid",
                                                                            src: solution_icon2.src,
                                                                            alt: "mega_menu_link_icon"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "mega_link_description",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                                children: "UI/UX Design"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                children: "UI/UX design is, of course, a defining component for each digital product."
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "/services/landing-page",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                                className: "mega_link_item",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "mega_link_icon",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                            className: "img-fluid",
                                                                            src: solution_icon3.src,
                                                                            alt: "mega_menu_link_icon"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "mega_link_description",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                                children: "Landing Page Design"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                children: "A well-designed landing page is your best bet for attracting new clients."
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "/services/wordpress",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                                className: "mega_link_item",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "mega_link_icon",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                            className: "img-fluid",
                                                                            src: solution_icon4.src,
                                                                            alt: "mega_menu_link_icon"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "mega_link_description",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                                children: "WordPress Development"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                children: "When it comes to getting the most out of WordPress CMS and seeing the results"
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "/services/branding",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                                className: "mega_link_item",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "mega_link_icon",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                            className: "img-fluid",
                                                                            src: solution_icon5.src,
                                                                            alt: "mega_menu_link_icon"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "mega_link_description",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                                children: "Logos and Branding"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                children: "As a branding agency, CreativePeoples is the ultimate choice for all-sized businesses."
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "/services/print-designs",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                                className: "mega_link_item",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "mega_link_icon",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                            className: "img-fluid",
                                                                            src: solution_icon6.src,
                                                                            alt: "mega_menu_link_icon"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "mega_link_description",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                                children: "Print Design"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                children: "CreativePeoples provides an engaging visual presentation that evokes an emotive response "
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/projects",
                                                children: "Projects"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/blog",
                                                children: "Blog"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/reviews",
                                                children: "Reviews"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/joinus/#open-job-positions",
                                                children: "Join Us"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/contact",
                                                children: "Contact Us"
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mobile-menu-nav d-xl-none d-lg-flex d-md-flex d-sm-flex d-flex justify-content-between align-items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                className: "mobile-logo",
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: logo.src,
                                    alt: "mobile-logo.png"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                id: "mobile-menu-trigger",
                                className: "hamburger-icon",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {})
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "desktop-header container custom_container d-flex justify-content-between align-items-center d-xl-flex d-lg-none d-md-none d-sm-none d-none",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "site-logo",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: logo.src,
                                            alt: "logo.png"
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                className: "site-menu",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/about",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    className: router.pathname === "/about" ? "active" : "",
                                                    children: "About"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/services",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: router.pathname === "/services" ? "active" : "",
                                                        children: "Services"
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                    className: "mega_menu_wrap",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "/services/responsive-web",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                                className: "mega_link_item",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "mega_link_icon",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                            className: "img-fluid",
                                                                            src: solution_icon1.src,
                                                                            alt: "mega_menu_link_icon"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "mega_link_description",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                                children: "Responsive Website Design"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                children: "Do you know, about 75% of your clients browse your website from mobile?"
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "/services/ui-ux-design",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                                className: "mega_link_item",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "mega_link_icon",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                            className: "img-fluid",
                                                                            src: solution_icon2.src,
                                                                            alt: "mega_menu_link_icon"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "mega_link_description",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                                children: "UI/UX Design"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                children: "UI/UX design is, of course, a defining component for each digital product."
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "/services/landing-page",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                                className: "mega_link_item",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "mega_link_icon",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                            className: "img-fluid",
                                                                            src: solution_icon3.src,
                                                                            alt: "mega_menu_link_icon"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "mega_link_description",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                                children: "Landing Page Design"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                children: "A well-designed landing page is your best bet for attracting new clients."
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "/services/wordpress",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                                className: "mega_link_item",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "mega_link_icon",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                            className: "img-fluid",
                                                                            src: solution_icon4.src,
                                                                            alt: "mega_menu_link_icon"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "mega_link_description",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                                children: "WordPress Development"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                children: "When it comes to getting the most out of WordPress CMS and seeing the results"
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "/services/branding",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                                className: "mega_link_item",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "mega_link_icon",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                            className: "img-fluid",
                                                                            src: solution_icon5.src,
                                                                            alt: "mega_menu_link_icon"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "mega_link_description",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                                children: "Logos and Branding"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                children: "As a branding agency, CreativePeoples is the ultimate choice for all-sized businesses."
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "/services/print-designs",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                                className: "mega_link_item",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "mega_link_icon",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                            className: "img-fluid",
                                                                            src: solution_icon6.src,
                                                                            alt: "mega_menu_link_icon"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "mega_link_description",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                                children: "Print Design"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                children: "CreativePeoples provides an engaging visual presentation that evokes an emotive response "
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/projects",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    className: router.pathname === "/projects" ? "active" : "",
                                                    children: "Projects"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/blog",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    className: router.pathname === "/blog" ? "active" : "",
                                                    children: "Blog"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/reviews",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    className: router.pathname === "/reviews" ? "active" : "",
                                                    children: "Reviews"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/joinus/#open-job-positions",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    className: router.pathname === "/joinus" ? "active" : "",
                                                    children: "Join Us"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/contact",
                                                children: "Contact"
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const header = (Header);

// EXTERNAL MODULE: external "react-mailchimp-subscribe"
var external_react_mailchimp_subscribe_ = __webpack_require__(3286);
var external_react_mailchimp_subscribe_default = /*#__PURE__*/__webpack_require__.n(external_react_mailchimp_subscribe_);
;// CONCATENATED MODULE: ./components/shared/Footer/NewsLetterFooter.js


const NewsLetterFooter = ({ status , message , onValidated  })=>{
    const emailRef = (0,external_react_.useRef)();
    const handleMC = (e)=>{
        e.preventDefault();
        onValidated({
            MERGE0: emailRef.current.value
        });
        e.target.reset();
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "newsletter",
        children: !message ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            onSubmit: handleMC,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                    htmlFor: "get_touch",
                    children: "Get in touch"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                    ref: emailRef,
                    type: "email",
                    placeholder: "Email",
                    required: true
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    type: "submit",
                    children: status ? status : "Subscribe"
                })
            ]
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "newsletter-alert",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                    children: message
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "far fa-check-circle"
                            }),
                            " "
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const Footer_NewsLetterFooter = (NewsLetterFooter);

// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
;// CONCATENATED MODULE: ./components/shared/Footer/MobileFooter.js



const MobileFooter = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Accordion, {
            defaultActiveKey: "0",
            className: " mobile-footer-accordion d-xl-none d-lg-none d-md-none d-sm-block d-block",
            id: "footerAccordion",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Accordion.Item, {
                    eventKey: "0",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Accordion.Header, {
                            className: "d-flex justify-content-between",
                            children: [
                                "Essential Links",
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "accordion-icons",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "fas fa-plus"
                                        }),
                                        " ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "fas fa-minus"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Accordion.Body, {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "footer_menu",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/",
                                            children: "Home"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/about",
                                            children: "About us"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/services",
                                            children: "Services"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/blog",
                                            children: "Blog"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/projects",
                                            children: "Projects"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/reviews",
                                            children: "Reviews"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/contact",
                                            children: "Contact Us"
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Accordion.Item, {
                    eventKey: "1",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Accordion.Header, {
                            children: [
                                "Services",
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "accordion-icons",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "fas fa-plus"
                                        }),
                                        " ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "fas fa-minus"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Accordion.Body, {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "footer_menu",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/services/responsive-web",
                                            children: "Responsive Web Design"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/services/ui-ux-design",
                                            children: "UI/UX Design"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/services/wordpress",
                                            children: "WordPress Development"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/services/landing-page",
                                            children: "Landing Page Design"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/services/branding",
                                            children: "Logos and Branding"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/services/print-designs",
                                            children: "Print Designs"
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Accordion.Item, {
                    eventKey: "2",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Accordion.Header, {
                            children: [
                                "Contact Info",
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "accordion-icons",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "fas fa-plus"
                                        }),
                                        " ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "fas fa-minus"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Accordion.Body, {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "footer_menu",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/services/responsive-web",
                                            children: "Responsive Web Design"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/services/ui-ux-design",
                                            children: "UI/UX Design"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/services/wordpress",
                                            children: "WordPress Development"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/services/landing-page",
                                            children: "Landing Page Design"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/services/branding",
                                            children: "Logos and Branding"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/services/print-designs",
                                            children: "Print Designs"
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Footer_MobileFooter = (MobileFooter);

;// CONCATENATED MODULE: ./components/shared/Footer/logo.png
/* harmony default export */ const Footer_logo = ({"src":"/_next/static/media/logo.cb68866c.png","height":49,"width":313,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAAK0lEQVR4nGP89++fCwMDAycjIyPr7/dvv36f087CeKn3/38uDX6Gfz+/AgDzIg/GIFgyKQAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./components/shared/Footer/Footer.js






const Footer = ()=>{
    const url = `https://creativepeoplesdesign.us14.list-manage.com/subscribe/post?u=24f115277814af39bffc7a263&id=4dd9d70cc2`;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: "cre_footer_section padding_top",
        style: {
            backgroundColor: "#1E2F3E"
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container custom_container",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "footer_newslwtter_form",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row align-items-center justify-content-between",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-5 wow fadeInLeft",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "footer_newsletter_content",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "title font_700 text-white",
                                            children: "Newsletter Sign Up"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-5 col-xl-4 wow fadeInRight",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "cre_newsletter_wrapper",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "cre_form_group",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_mailchimp_subscribe_default()), {
                                                url: url,
                                                render: ({ subscribe , status , message  })=>/*#__PURE__*/ jsx_runtime_.jsx(Footer_NewsLetterFooter, {
                                                        status: status,
                                                        message: message,
                                                        onValidated: (formData)=>subscribe(formData)
                                                    })
                                            })
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row justify-content-between",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-12 col-xl-3 col-sm-6 wow fadeInUp",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "cre_footer_widget",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: Footer_logo.src,
                                            alt: "/",
                                            className: "footer_logo"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "social_icon",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    rel: "noreferrer",
                                                    target: "_blank",
                                                    href: "https://www.facebook.com/oyolloo",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fab fa-facebook-f"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    rel: "noreferrer",
                                                    target: "_blank",
                                                    href: "https://twitter.com/oyolloo/",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fab fa-twitter"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    rel: "noreferrer",
                                                    target: "_blank",
                                                    href: "https://dribbble.com/Oyolloo",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fab fa-dribbble"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    rel: "noreferrer",
                                                    target: "_blank",
                                                    href: "https://www.linkedin.com/company/oyolloo/mycompany/",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fab fa-linkedin-in"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Footer_MobileFooter, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-4 col-xl-2 col-sm-6 wow fadeInUp d-xl-block d-lg-block d-md-block d-sm-none d-none",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "cre_footer_widget",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "widget_title",
                                            children: "Essential Links"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "footer_menu",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/",
                                                        children: "Home"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/about",
                                                        children: "About us"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/services",
                                                        children: "Services"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/blog",
                                                        children: "Blog"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/projects",
                                                        children: "Projects"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/reviews",
                                                        children: "Reviews"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/contact",
                                                        children: "Contact Us"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-4 col-xl-3 col-sm-6 wow fadeInUp d-xl-block d-lg-block d-md-block d-sm-none d-none",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "cre_footer_widget",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "widget_title",
                                            children: "Services"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "footer_menu",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/services/responsive-web",
                                                        children: "Responsive Web Design"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/services/ui-ux-design",
                                                        children: "UI/UX Design"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/services/wordpress",
                                                        children: "WordPress Development"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/services/landing-page",
                                                        children: "Landing Page Design"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/services/branding",
                                                        children: "Logos and Branding"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/services/print-designs",
                                                        children: "Print Designs"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-4 col-xl-3 col-sm-6 wow fadeInUp d-xl-block d-lg-block d-md-block d-sm-none d-none",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "cre_footer_widget",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "widget_title",
                                            children: "Contact Info"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "footer_menu",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "tel:+8801758500436",
                                                        children: "+8801758500436"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "mailto:hello@creativepeoplesdesign.com",
                                                        children: "hello@creativepeoplesdesign.com"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "House 12/1, R 4/A, Dhanmondi, Dhaka"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("iframe", {
                                            src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3652.1984632707367!2d90.3714182159617!3d23.74030119507684!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755bf4a959a3969%3A0xb9dbf8443fe868b6!2sHouse%20No-12%2C%201%20Road%20No.%204A%2C%20Dhaka%201209!5e0!3m2!1sen!2sbd!4v1649801951076!5m2!1sen!2sbd",
                                            width: "380",
                                            height: "300",
                                            style: {
                                                border: 0
                                            },
                                            loading: "lazy",
                                            referrerPolicy: "no-referrer-when-downgrade"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "dl_col_lg_12 wow fadeInUp",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "cre_copyright_content",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "copyright_content_inner",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Copyright \xa9 2022, All Rights Reserved"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "copyright_content_inner",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "/terms-and-conditions",
                                                            children: "Terms & Conditions"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "/privacy-policy",
                                                            children: "Privacy Policy"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "/disclaimer",
                                                            children: "Disclaimer"
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: "#scrollToTop",
                className: "scroll-top",
                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                    className: "fas fa-arrow-up"
                })
            })
        ]
    });
};
/* harmony default export */ const Footer_Footer = (Footer);

;// CONCATENATED MODULE: ./components/shared/Layout/Layout.js



const Layout = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header, {}),
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(Footer_Footer, {})
        ]
    });
};
/* harmony default export */ const Layout_Layout = (Layout);


/***/ })

};
;